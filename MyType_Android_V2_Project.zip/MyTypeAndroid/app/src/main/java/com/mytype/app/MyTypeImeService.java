package com.mytype.app;

import android.inputmethodservice.InputMethodService;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.view.inputmethod.InputConnection;
import android.widget.*;
import java.io.File;

public class MyTypeImeService extends InputMethodService {
    LinearLayout root; boolean shift=false, symbols=false;
    String[] letters={"QWERTYUIOP","ASDFGHJKL","ZXCVBNM"};
    @Override public View onCreateInputView(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(6,6,6,6);root.setBackgroundColor(Color.rgb(32,32,32));
        build();return root;
    }
    void build(){root.removeAllViews();
        if(symbols){addRow("1234567890");addRow("@#$%&*-+=()");addRow(".,!?/:;'");}
        else {for(String row:letters)addRow(row);}
        LinearLayout bottom=new LinearLayout(this);
        Button shiftB=btn(shift?"⇧ ON":"⇧");shiftB.setOnClickListener(v->{shift=!shift;build();});bottom.addView(shiftB,new LinearLayout.LayoutParams(0,58,1));
        Button sym=btn(symbols?"ABC":"123");sym.setOnClickListener(v->{symbols=!symbols;build();});bottom.addView(sym,new LinearLayout.LayoutParams(0,58,1));
        Button sp=btn("space");sp.setOnClickListener(v->commit(" "));bottom.addView(sp,new LinearLayout.LayoutParams(0,58,3));
        Button del=btn("⌫");del.setOnClickListener(v->{InputConnection ic=getCurrentInputConnection();if(ic!=null)ic.deleteSurroundingText(1,0);});bottom.addView(del,new LinearLayout.LayoutParams(0,58,1));
        Button enter=btn("↵");enter.setOnClickListener(v->commit("\n"));bottom.addView(enter,new LinearLayout.LayoutParams(0,58,1));root.addView(bottom);
    }
    void addRow(String row){LinearLayout r=new LinearLayout(this);for(char raw:row.toCharArray()){final char ch=raw;Button b=btn(String.valueOf(shift?Character.toUpperCase(ch):Character.toLowerCase(ch)));if(!symbols){File f=new File(getFilesDir(),String.valueOf(Character.toUpperCase(ch))+".png");if(f.exists()){Bitmap bm=BitmapFactory.decodeFile(f.getAbsolutePath());b.setCompoundDrawablesWithIntrinsicBounds(new BitmapDrawable(getResources(),bm),null,null,null);b.setText("");}}b.setOnClickListener(v->{commit(String.valueOf(shift?Character.toUpperCase(ch):Character.toLowerCase(ch)));if(shift){shift=false;build();}});r.addView(b,new LinearLayout.LayoutParams(0,58,1));}root.addView(r);}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(13);return b;}void commit(String s){InputConnection ic=getCurrentInputConnection();if(ic!=null)ic.commitText(s,1);}
}
